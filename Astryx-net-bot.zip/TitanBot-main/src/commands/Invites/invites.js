import { SlashCommandBuilder, PermissionFlagsBits, ChannelType } from 'discord.js';
import { createEmbed, successEmbed } from '../../utils/embeds.js';
import { getGuildConfig, patchGuildConfig } from '../../services/config/guildConfig.js';
import { getInviterCount, getInviteLeaderboard } from '../../services/inviteTrackerService.js';
import { logger } from '../../utils/logger.js';
import { AstryxError, ErrorTypes, replyUserError } from '../../utils/errorHandler.js';
import { InteractionHelper } from '../../utils/interactionHelper.js';

export default {
    data: new SlashCommandBuilder()
        .setName('invites')
        .setDescription('Set up and view the invite tracker')
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
        .addSubcommand((sub) =>
            sub
                .setName('setup')
                .setDescription('Set the channel where new invite joins are announced')
                .addChannelOption((o) =>
                    o
                        .setName('channel')
                        .setDescription('Channel to post invite-join announcements in')
                        .addChannelTypes(ChannelType.GuildText)
                        .setRequired(true),
                ),
        )
        .addSubcommand((sub) =>
            sub.setName('disable').setDescription('Turn off invite-join announcements'),
        )
        .addSubcommand((sub) =>
            sub
                .setName('view')
                .setDescription("View a member's total invite count")
                .addUserOption((o) =>
                    o.setName('user').setDescription('User to check (defaults to you)').setRequired(false),
                ),
        )
        .addSubcommand((sub) =>
            sub.setName('leaderboard').setDescription('Show the top inviters in this server'),
        ),
    category: 'invites',

    async execute(interaction, config, client) {
        const deferSuccess = await InteractionHelper.safeDefer(interaction);
        if (!deferSuccess) {
            logger.warn('Invites interaction defer failed', {
                userId: interaction.user.id,
                guildId: interaction.guildId,
                commandName: 'invites',
            });
            return;
        }

        const { guild } = interaction;
        const subcommand = interaction.options.getSubcommand();

        if (subcommand === 'setup') {
            if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild)) {
                return await replyUserError(interaction, {
                    type: ErrorTypes.PERMISSION,
                    message: 'You need the **Manage Server** permission to configure the invite tracker.',
                });
            }

            const channel = interaction.options.getChannel('channel');
            const me = guild.members.me;
            const permissions = channel.permissionsFor(me);

            if (!permissions?.has([PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.EmbedLinks])) {
                throw new AstryxError(
                    'Missing channel permissions',
                    ErrorTypes.PERMISSION,
                    `I need **View Channel**, **Send Messages**, and **Embed Links** in ${channel} to post invite announcements there.`,
                );
            }

            await patchGuildConfig(client, guild.id, {
                inviteTracking: { enabled: true, channelId: channel.id },
            });

            return await InteractionHelper.safeEditReply(interaction, {
                embeds: [
                    successEmbed(
                        '✅ Invite Tracker Configured',
                        `New member joins will now be announced in ${channel}, showing who invited them and their total invite count.`,
                    ),
                ],
            });
        }

        if (subcommand === 'disable') {
            if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild)) {
                return await replyUserError(interaction, {
                    type: ErrorTypes.PERMISSION,
                    message: 'You need the **Manage Server** permission to configure the invite tracker.',
                });
            }

            await patchGuildConfig(client, guild.id, {
                inviteTracking: { enabled: false },
            });

            return await InteractionHelper.safeEditReply(interaction, {
                embeds: [successEmbed('✅ Invite Tracker Disabled', 'Invite-join announcements have been turned off.')],
            });
        }

        if (subcommand === 'view') {
            const target = interaction.options.getUser('user') || interaction.user;
            const total = await getInviterCount(guild.id, target.id);

            return await InteractionHelper.safeEditReply(interaction, {
                embeds: [
                    createEmbed({
                        title: '📨 Invite Count',
                        color: 'primary',
                        description: `${target} has invited **${total}** member${total === 1 ? '' : 's'} to this server.`,
                        thumbnail: target.displayAvatarURL(),
                    }),
                ],
            });
        }

        if (subcommand === 'leaderboard') {
            const leaderboard = await getInviteLeaderboard(guild.id, 10);

            if (!leaderboard.length) {
                return await InteractionHelper.safeEditReply(interaction, {
                    embeds: [
                        createEmbed({
                            title: '📨 Invite Leaderboard',
                            color: 'primary',
                            description: 'No tracked invites yet. Once members start joining via invite links, they’ll show up here.',
                        }),
                    ],
                });
            }

            const lines = leaderboard.map(
                (entry, index) => `**${index + 1}.** <@${entry.inviterId}> — ${entry.total} invite${entry.total === 1 ? '' : 's'}`,
            );

            return await InteractionHelper.safeEditReply(interaction, {
                embeds: [
                    createEmbed({
                        title: '📨 Invite Leaderboard',
                        color: 'primary',
                        description: lines.join('\n'),
                    }),
                ],
            });
        }
    },
};
