import { SlashCommandBuilder, PermissionFlagsBits, ChannelType } from 'discord.js';
import { createEmbed, successEmbed } from '../../utils/embeds.js';
import { getGuildConfig, patchGuildConfig } from '../../services/config/guildConfig.js';
import { InteractionHelper } from '../../utils/interactionHelper.js';
import { logger } from '../../utils/logger.js';
import { replyUserError, ErrorTypes } from '../../utils/errorHandler.js';
import {
    triggerLockdown,
    liftLockdown,
    isRaidModeActive,
} from '../../services/antiRaidService.js';

export default {
    data: new SlashCommandBuilder()
        .setName('security')
        .setDescription('Configure anti-raid and anti-spam protection')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
        .addSubcommandGroup((group) =>
            group
                .setName('raid')
                .setDescription('Anti-raid protection (mass-join detection + lockdown)')
                .addSubcommand((sub) =>
                    sub
                        .setName('setup')
                        .setDescription('Configure anti-raid protection')
                        .addBooleanOption((o) => o.setName('enabled').setDescription('Turn anti-raid protection on/off'))
                        .addIntegerOption((o) =>
                            o.setName('join_threshold').setDescription('Number of joins that triggers raid mode').setMinValue(3).setMaxValue(100),
                        )
                        .addIntegerOption((o) =>
                            o.setName('join_window_seconds').setDescription('Time window (seconds) for the join threshold').setMinValue(5).setMaxValue(300),
                        )
                        .addIntegerOption((o) =>
                            o.setName('min_account_age_hours').setDescription('Flag accounts younger than this many hours (0 = disabled)').setMinValue(0).setMaxValue(720),
                        )
                        .addStringOption((o) =>
                            o
                                .setName('new_account_action')
                                .setDescription('Action taken on accounts younger than the age threshold')
                                .addChoices(
                                    { name: 'Kick', value: 'kick' },
                                    { name: 'Ban', value: 'ban' },
                                    { name: 'Quarantine (assign role)', value: 'quarantine' },
                                    { name: 'None (alert only)', value: 'none' },
                                ),
                        )
                        .addRoleOption((o) => o.setName('quarantine_role').setDescription('Role to assign when action is "Quarantine"'))
                        .addBooleanOption((o) => o.setName('lockdown_on_trigger').setDescription('Auto-lock text channels when a raid is detected'))
                        .addChannelOption((o) =>
                            o.setName('alert_channel').setDescription('Channel for raid alerts').addChannelTypes(ChannelType.GuildText),
                        ),
                )
                .addSubcommand((sub) => sub.setName('status').setDescription('View current anti-raid configuration'))
                .addSubcommand((sub) => sub.setName('lockdown').setDescription('Manually lock all text channels right now'))
                .addSubcommand((sub) => sub.setName('unlock').setDescription('Lift an active lockdown')),
        )
        .addSubcommandGroup((group) =>
            group
                .setName('spam')
                .setDescription('Anti-spam protection (message-rate + mass mentions)')
                .addSubcommand((sub) =>
                    sub
                        .setName('setup')
                        .setDescription('Configure anti-spam protection')
                        .addBooleanOption((o) => o.setName('enabled').setDescription('Turn anti-spam protection on/off'))
                        .addIntegerOption((o) =>
                            o.setName('message_threshold').setDescription('Messages that trigger spam detection').setMinValue(3).setMaxValue(50),
                        )
                        .addIntegerOption((o) =>
                            o.setName('message_window_seconds').setDescription('Time window (seconds) for the message threshold').setMinValue(2).setMaxValue(60),
                        )
                        .addIntegerOption((o) =>
                            o.setName('mention_threshold').setDescription('Mentions in a single message that trigger spam detection').setMinValue(3).setMaxValue(50),
                        )
                        .addStringOption((o) =>
                            o
                                .setName('action')
                                .setDescription('Action taken against spammers')
                                .addChoices(
                                    { name: 'Timeout', value: 'timeout' },
                                    { name: 'Kick', value: 'kick' },
                                    { name: 'Ban', value: 'ban' },
                                ),
                        )
                        .addIntegerOption((o) =>
                            o.setName('timeout_minutes').setDescription('Timeout duration in minutes (if action is Timeout)').setMinValue(1).setMaxValue(10080),
                        )
                        .addBooleanOption((o) => o.setName('delete_messages').setDescription('Delete the spam messages'))
                        .addChannelOption((o) =>
                            o.setName('alert_channel').setDescription('Channel for spam alerts').addChannelTypes(ChannelType.GuildText),
                        ),
                )
                .addSubcommand((sub) => sub.setName('status').setDescription('View current anti-spam configuration')),
        ),
    category: 'moderation',

    async execute(interaction, config, client) {
        const deferSuccess = await InteractionHelper.safeDefer(interaction);
        if (!deferSuccess) {
            logger.warn('Security interaction defer failed', {
                userId: interaction.user.id,
                guildId: interaction.guildId,
                commandName: 'security',
            });
            return;
        }

        if (!interaction.memberPermissions?.has(PermissionFlagsBits.Administrator)) {
            return await replyUserError(interaction, {
                type: ErrorTypes.PERMISSION,
                message: 'You need **Administrator** permission to configure security settings.',
            });
        }

        const { guild } = interaction;
        const group = interaction.options.getSubcommandGroup();
        const subcommand = interaction.options.getSubcommand();
        const currentConfig = await getGuildConfig(client, guild.id);
        const security = currentConfig?.security || {};

        if (group === 'raid') {
            if (subcommand === 'setup') {
                const antiRaid = { ...security.antiRaid };

                const setIfProvided = (optName, key, transform = (v) => v) => {
                    const val = interaction.options.get(optName)?.value;
                    if (val !== undefined && val !== null) antiRaid[key] = transform(val);
                };

                setIfProvided('enabled', 'enabled');
                setIfProvided('join_threshold', 'joinThreshold');
                setIfProvided('join_window_seconds', 'joinWindowSeconds');
                setIfProvided('min_account_age_hours', 'minAccountAgeHours');
                setIfProvided('new_account_action', 'newAccountAction');
                setIfProvided('lockdown_on_trigger', 'lockdownOnTrigger');

                const quarantineRole = interaction.options.getRole('quarantine_role');
                if (quarantineRole) antiRaid.quarantineRoleId = quarantineRole.id;

                const alertChannel = interaction.options.getChannel('alert_channel');
                if (alertChannel) antiRaid.alertChannelId = alertChannel.id;

                await patchGuildConfig(client, guild.id, { security: { antiRaid } });

                return await InteractionHelper.safeEditReply(interaction, {
                    embeds: [successEmbed('🛡️ Anti-Raid Updated', 'Your anti-raid settings have been saved. Use `/security raid status` to review them.')],
                });
            }

            if (subcommand === 'status') {
                const ar = { ...security.antiRaid };
                return await InteractionHelper.safeEditReply(interaction, {
                    embeds: [
                        createEmbed({
                            title: '🛡️ Anti-Raid Status',
                            color: ar.enabled ? 'success' : 'muted',
                            description:
                                `**Enabled:** ${ar.enabled ? 'Yes' : 'No'}\n` +
                                `**Join Threshold:** ${ar.joinThreshold ?? 8} joins / ${ar.joinWindowSeconds ?? 15}s\n` +
                                `**Min Account Age:** ${ar.minAccountAgeHours ?? 24}h\n` +
                                `**New Account Action:** ${ar.newAccountAction ?? 'kick'}\n` +
                                `**Quarantine Role:** ${ar.quarantineRoleId ? `<@&${ar.quarantineRoleId}>` : 'Not set'}\n` +
                                `**Lockdown on Trigger:** ${ar.lockdownOnTrigger === false ? 'No' : 'Yes'}\n` +
                                `**Alert Channel:** ${ar.alertChannelId ? `<#${ar.alertChannelId}>` : 'Not set'}\n` +
                                `**Currently Locked Down:** ${isRaidModeActive(guild.id) ? '🔒 Yes' : 'No'}`,
                        }),
                    ],
                });
            }

            if (subcommand === 'lockdown') {
                const { locked } = await triggerLockdown(guild, `Manual lockdown by ${interaction.user.tag}`);
                return await InteractionHelper.safeEditReply(interaction, {
                    embeds: [successEmbed('🔒 Server Locked Down', `Locked **${locked.length}** channel(s). Use \`/security raid unlock\` to restore.`)],
                });
            }

            if (subcommand === 'unlock') {
                const { unlocked } = await liftLockdown(guild, `Manual unlock by ${interaction.user.tag}`);
                if (!unlocked.length) {
                    return await InteractionHelper.safeEditReply(interaction, {
                        embeds: [createEmbed({ title: '🔓 Nothing to Unlock', color: 'primary', description: 'No active lockdown was found.' })],
                    });
                }
                return await InteractionHelper.safeEditReply(interaction, {
                    embeds: [successEmbed('🔓 Lockdown Lifted', `Restored **${unlocked.length}** channel(s).`)],
                });
            }
        }

        if (group === 'spam') {
            if (subcommand === 'setup') {
                const antiSpam = { ...security.antiSpam };

                const setIfProvided = (optName, key, transform = (v) => v) => {
                    const val = interaction.options.get(optName)?.value;
                    if (val !== undefined && val !== null) antiSpam[key] = transform(val);
                };

                setIfProvided('enabled', 'enabled');
                setIfProvided('message_threshold', 'messageThreshold');
                setIfProvided('message_window_seconds', 'messageWindowSeconds');
                setIfProvided('mention_threshold', 'mentionThreshold');
                setIfProvided('action', 'action');
                setIfProvided('timeout_minutes', 'timeoutMs', (v) => v * 60000);
                setIfProvided('delete_messages', 'deleteMessages');

                const alertChannel = interaction.options.getChannel('alert_channel');
                if (alertChannel) antiSpam.alertChannelId = alertChannel.id;

                await patchGuildConfig(client, guild.id, { security: { antiSpam } });

                return await InteractionHelper.safeEditReply(interaction, {
                    embeds: [successEmbed('🚨 Anti-Spam Updated', 'Your anti-spam settings have been saved. Use `/security spam status` to review them.')],
                });
            }

            if (subcommand === 'status') {
                const as = { ...security.antiSpam };
                return await InteractionHelper.safeEditReply(interaction, {
                    embeds: [
                        createEmbed({
                            title: '🚨 Anti-Spam Status',
                            color: as.enabled ? 'success' : 'muted',
                            description:
                                `**Enabled:** ${as.enabled ? 'Yes' : 'No'}\n` +
                                `**Message Threshold:** ${as.messageThreshold ?? 6} msgs / ${as.messageWindowSeconds ?? 6}s\n` +
                                `**Mention Threshold:** ${as.mentionThreshold ?? 5} mentions/message\n` +
                                `**Action:** ${as.action ?? 'timeout'}${as.action === 'timeout' || !as.action ? ` (${Math.round((as.timeoutMs ?? 600000) / 60000)}m)` : ''}\n` +
                                `**Delete Messages:** ${as.deleteMessages === false ? 'No' : 'Yes'}\n` +
                                `**Alert Channel:** ${as.alertChannelId ? `<#${as.alertChannelId}>` : 'Not set'}`,
                        }),
                    ],
                });
            }
        }
    },
};
