import { Events } from 'discord.js';
import { logger } from '../utils/logger.js';
import { cacheGuildInvites } from '../services/inviteTrackerService.js';

export default {
  name: Events.InviteCreate,
  once: false,

  async execute(invite) {
    try {
      if (!invite.guild) return;
      await cacheGuildInvites(invite.guild);
    } catch (error) {
      logger.error(`Error handling inviteCreate for guild ${invite.guild?.id}:`, error);
    }
  },
};
