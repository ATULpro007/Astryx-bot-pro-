import { Events } from 'discord.js';
import { logger } from '../utils/logger.js';
import { cacheGuildInvites } from '../services/inviteTrackerService.js';

export default {
  name: Events.InviteDelete,
  once: false,

  async execute(invite) {
    try {
      if (!invite.guild) return;
      // A short delay avoids a race with guildMemberAdd's own diffing when a
      // single-use invite is deleted immediately after being consumed.
      setTimeout(() => {
        cacheGuildInvites(invite.guild).catch((err) =>
          logger.warn(`Invite cache refresh failed after inviteDelete in ${invite.guild.id}: ${err.message}`)
        );
      }, 5000);
    } catch (error) {
      logger.error(`Error handling inviteDelete for guild ${invite.guild?.id}:`, error);
    }
  },
};
