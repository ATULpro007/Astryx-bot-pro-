// antiRaidService.js — join-rate raid detection, new-account gating, and
// guild-wide lockdown/unlock.

import { PermissionFlagsBits, ChannelType } from 'discord.js';
import { logger } from '../utils/logger.js';
import { createEmbed } from '../utils/embeds.js';
import { getGuildConfig } from './config/guildConfig.js';
import { ModerationService } from './moderation/moderationService.js';
import { logModerationAction } from '../utils/moderation.js';

// guildId -> array of join timestamps (ms)
const joinBuffers = new Map();
// guildId -> { active: boolean, lockedChannelIds: string[], triggeredAt: number }
const raidState = new Map();

function pruneAndPush(buffer, windowMs, now) {
    const cutoff = now - windowMs;
    while (buffer.length && buffer[0] < cutoff) {
        buffer.shift();
    }
    buffer.push(now);
    return buffer;
}

async function sendAlert(guild, channelId, embed) {
    if (!channelId) return;
    try {
        const channel = guild.channels.cache.get(channelId);
        const me = guild.members.me;
        const perms = channel?.isTextBased?.() && me ? channel.permissionsFor(me) : null;
        if (!perms?.has([PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.EmbedLinks])) {
            return;
        }
        await channel.send({ embeds: [embed] });
    } catch (error) {
        logger.warn(`Anti-raid alert failed in guild ${guild.id}: ${error.message}`);
    }
}

export function isRaidModeActive(guildId) {
    return raidState.get(guildId)?.active === true;
}

export async function triggerLockdown(guild, reason = 'Raid protection triggered') {
    const me = guild.members.me;
    if (!me?.permissions?.has(PermissionFlagsBits.ManageChannels)) {
        logger.warn(`Cannot lock down guild ${guild.id} — missing Manage Channels permission.`);
        return { locked: [] };
    }

    const everyoneRole = guild.roles.everyone;
    const textChannels = guild.channels.cache.filter(
        (c) => (c.type === ChannelType.GuildText || c.type === ChannelType.GuildAnnouncement) && c.viewable,
    );

    const lockedChannelIds = [];

    for (const channel of textChannels.values()) {
        try {
            const current = channel.permissionsFor(everyoneRole);
            if (current?.has(PermissionFlagsBits.SendMessages) === false) {
                continue; // already locked, don't touch / don't restore later
            }
            await channel.permissionOverwrites.edit(everyoneRole, { SendMessages: false }, { reason });
            lockedChannelIds.push(channel.id);
        } catch (error) {
            logger.warn(`Failed to lock channel ${channel.id} in ${guild.id}: ${error.message}`);
        }
    }

    raidState.set(guild.id, { active: true, lockedChannelIds, triggeredAt: Date.now() });
    return { locked: lockedChannelIds };
}

export async function liftLockdown(guild, reason = 'Raid protection lifted') {
    const state = raidState.get(guild.id);
    if (!state?.active) {
        return { unlocked: [] };
    }

    const everyoneRole = guild.roles.everyone;
    const unlocked = [];

    for (const channelId of state.lockedChannelIds) {
        const channel = guild.channels.cache.get(channelId);
        if (!channel) continue;
        try {
            await channel.permissionOverwrites.edit(everyoneRole, { SendMessages: null }, { reason });
            unlocked.push(channelId);
        } catch (error) {
            logger.warn(`Failed to unlock channel ${channelId} in ${guild.id}: ${error.message}`);
        }
    }

    raidState.set(guild.id, { active: false, lockedChannelIds: [], triggeredAt: null });
    return { unlocked };
}

async function handleNewAccount(member, config, accountAgeHours) {
    const action = config.newAccountAction || 'kick';
    const reason = `Anti-raid: account created ${accountAgeHours.toFixed(1)}h ago (under ${config.minAccountAgeHours}h threshold)`;

    try {
        if (action === 'none') return null;

        if (action === 'quarantine' && config.quarantineRoleId) {
            const role = member.guild.roles.cache.get(config.quarantineRoleId);
            if (role) {
                await member.roles.add(role, reason);
                return { action: 'quarantine' };
            }
        }

        if (action === 'kick' && member.kickable) {
            await ModerationService.kickUser({
                guild: member.guild,
                member,
                moderator: member.guild.members.me,
                reason,
            });
            return { action: 'kick' };
        }

        if (action === 'ban' && member.bannable) {
            await ModerationService.banUser({
                guild: member.guild,
                user: member.user,
                moderator: member.guild.members.me,
                reason,
            });
            return { action: 'ban' };
        }
    } catch (error) {
        logger.warn(`Anti-raid new-account action failed for ${member.id} in ${member.guild.id}: ${error.message}`);
    }

    return null;
}

/**
 * Called on every guildMemberAdd. Handles new-account gating and join-rate
 * raid detection/lockdown.
 */
export async function evaluateJoin(member) {
    if (member.user.bot) return;

    try {
        const config = await getGuildConfig(member.client, member.guild.id);
        const antiRaid = config?.security?.antiRaid;
        if (!antiRaid?.enabled) return;

        const now = Date.now();

        // --- New-account gating ---
        if (antiRaid.minAccountAgeHours > 0) {
            const accountAgeHours = (now - member.user.createdTimestamp) / (1000 * 60 * 60);
            if (accountAgeHours < antiRaid.minAccountAgeHours) {
                const result = await handleNewAccount(member, antiRaid, accountAgeHours);
                if (result) {
                    await sendAlert(
                        member.guild,
                        antiRaid.alertChannelId,
                        createEmbed({
                            title: '🛡️ Anti-Raid: New Account Blocked',
                            color: 'warning',
                            description: `${member.user.tag} (\`${member.id}\`) joined with an account only **${accountAgeHours.toFixed(1)}h** old.\nAction taken: **${result.action}**`,
                            timestamp: true,
                        }),
                    );
                }
            }
        }

        // --- Join-rate raid detection ---
        const windowMs = (antiRaid.joinWindowSeconds || 15) * 1000;
        const buffer = pruneAndPush(joinBuffers.get(member.guild.id) || [], windowMs, now);
        joinBuffers.set(member.guild.id, buffer);

        if (buffer.length >= (antiRaid.joinThreshold || 8) && !isRaidModeActive(member.guild.id)) {
            logger.warn(`Raid detected in guild ${member.guild.id}: ${buffer.length} joins in ${antiRaid.joinWindowSeconds}s`);

            let lockedCount = 0;
            if (antiRaid.lockdownOnTrigger) {
                const { locked } = await triggerLockdown(member.guild, 'Anti-raid: join-rate threshold exceeded');
                lockedCount = locked.length;
            } else {
                raidState.set(member.guild.id, { active: true, lockedChannelIds: [], triggeredAt: now });
            }

            await sendAlert(
                member.guild,
                antiRaid.alertChannelId,
                createEmbed({
                    title: '🚨 Raid Detected',
                    color: 'error',
                    description:
                        `**${buffer.length} members** joined within ${antiRaid.joinWindowSeconds} seconds.\n` +
                        (antiRaid.lockdownOnTrigger
                            ? `🔒 Locked **${lockedCount}** channel(s). Use \`/security raid unlock\` when it's safe.`
                            : `Lockdown is disabled — review new members manually.`),
                    timestamp: true,
                }),
            );

            await logModerationAction({
                client: member.client,
                guild: member.guild,
                event: {
                    action: 'Raid Detected',
                    target: member.guild.name,
                    executor: 'Anti-Raid System',
                    reason: `${buffer.length} joins within ${antiRaid.joinWindowSeconds}s`,
                    metadata: { lockedChannels: lockedCount },
                },
            }).catch(() => {});
        }
    } catch (error) {
        logger.error(`Anti-raid evaluation failed for ${member.id} in ${member.guild.id}:`, error);
    }
}

export function clearGuildRaidState(guildId) {
    joinBuffers.delete(guildId);
    raidState.delete(guildId);
}
