// antiSpamService.js — message-rate and mass-mention spam detection with
// automatic moderation action.

import { PermissionFlagsBits } from 'discord.js';
import { logger } from '../utils/logger.js';
import { createEmbed } from '../utils/embeds.js';
import { getGuildConfig } from './config/guildConfig.js';
import { ModerationService } from './moderation/moderationService.js';

// guildId -> userId -> array of { ts, messageId, channelId }
const messageBuffers = new Map();
// guildId -> Set(userId) currently being actioned, to avoid double-triggering
const inFlight = new Map();

function getUserBuffer(guildId, userId) {
    if (!messageBuffers.has(guildId)) {
        messageBuffers.set(guildId, new Map());
    }
    const guildMap = messageBuffers.get(guildId);
    if (!guildMap.has(userId)) {
        guildMap.set(userId, []);
    }
    return guildMap.get(userId);
}

async function sendAlert(guild, channelId, embed) {
    if (!channelId) return;
    try {
        const channel = guild.channels.cache.get(channelId);
        const me = guild.members.me;
        const perms = channel?.isTextBased?.() && me ? channel.permissionsFor(me) : null;
        if (!perms?.has([PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.EmbedLinks])) {
            return;
        }
        await channel.send({ embeds: [embed] });
    } catch (error) {
        logger.warn(`Anti-spam alert failed in guild ${guild.id}: ${error.message}`);
    }
}

async function purgeRecent(message, entries) {
    try {
        const ids = entries.map((e) => e.messageId).filter(Boolean);
        if (!ids.length) return;
        await message.channel.bulkDelete(ids, true).catch(() => {});
    } catch (error) {
        logger.warn(`Anti-spam purge failed in ${message.guild.id}: ${error.message}`);
    }
}

async function applyAction(member, action, reason, timeoutMs) {
    try {
        if (action === 'timeout' && member.moderatable) {
            await ModerationService.timeoutUser({
                guild: member.guild,
                member,
                moderator: member.guild.members.me,
                durationMs: timeoutMs || 600000,
                reason,
            });
            return 'timeout';
        }
        if (action === 'kick' && member.kickable) {
            await ModerationService.kickUser({
                guild: member.guild,
                member,
                moderator: member.guild.members.me,
                reason,
            });
            return 'kick';
        }
        if (action === 'ban' && member.bannable) {
            await ModerationService.banUser({
                guild: member.guild,
                user: member.user,
                moderator: member.guild.members.me,
                reason,
            });
            return 'ban';
        }
    } catch (error) {
        logger.warn(`Anti-spam action failed for ${member.id} in ${member.guild.id}: ${error.message}`);
    }
    return null;
}

/**
 * Called on every messageCreate (guild text messages only, non-bots).
 * Detects rapid-fire message spam and mass-mention spam.
 */
export async function evaluateMessage(message) {
    if (message.author.bot || !message.guild || !message.member) return;

    try {
        const config = await getGuildConfig(message.client, message.guild.id);
        const antiSpam = config?.security?.antiSpam;
        if (!antiSpam?.enabled) return;

        const guildId = message.guild.id;
        const userId = message.author.id;
        const now = Date.now();

        const guildInFlight = inFlight.get(guildId) || new Set();
        if (guildInFlight.has(userId)) return;

        // --- Mass-mention detection (instant trigger, no window needed) ---
        const mentionCount = message.mentions.users.size + message.mentions.roles.size;
        if (antiSpam.mentionThreshold > 0 && mentionCount >= antiSpam.mentionThreshold) {
            await triggerSpamAction(message, antiSpam, [{ messageId: message.id }], `Mass mentions (${mentionCount} in one message)`);
            return;
        }

        // --- Rate-based spam detection ---
        const windowMs = (antiSpam.messageWindowSeconds || 6) * 1000;
        const buffer = getUserBuffer(guildId, userId);
        const cutoff = now - windowMs;
        while (buffer.length && buffer[0].ts < cutoff) {
            buffer.shift();
        }
        buffer.push({ ts: now, messageId: message.id, channelId: message.channel.id });

        if (buffer.length >= (antiSpam.messageThreshold || 6)) {
            const recent = [...buffer];
            buffer.length = 0;
            await triggerSpamAction(message, antiSpam, recent, `${recent.length} messages within ${antiSpam.messageWindowSeconds}s`);
        }
    } catch (error) {
        logger.error(`Anti-spam evaluation failed for ${message.author.id} in ${message.guild?.id}:`, error);
    }
}

async function triggerSpamAction(message, antiSpam, entries, reasonDetail) {
    const guildId = message.guild.id;
    const userId = message.author.id;

    const guildInFlight = inFlight.get(guildId) || new Set();
    guildInFlight.add(userId);
    inFlight.set(guildId, guildInFlight);

    try {
        const reason = `Anti-spam: ${reasonDetail}`;

        if (antiSpam.deleteMessages) {
            await purgeRecent(message, entries);
        }

        const actionTaken = await applyAction(message.member, antiSpam.action || 'timeout', reason, antiSpam.timeoutMs);

        await sendAlert(
            message.guild,
            antiSpam.alertChannelId,
            createEmbed({
                title: '🚨 Spam Detected',
                color: 'warning',
                description:
                    `${message.author} (\`${userId}\`) triggered anti-spam in <#${message.channel.id}>.\n` +
                    `**Reason:** ${reasonDetail}\n` +
                    `**Action:** ${actionTaken || 'none (missing permissions or already actioned)'}`,
                timestamp: true,
            }),
        );
    } finally {
        setTimeout(() => {
            inFlight.get(guildId)?.delete(userId);
        }, 3000);
    }
}

export function clearGuildSpamState(guildId) {
    messageBuffers.delete(guildId);
    inFlight.delete(guildId);
}
