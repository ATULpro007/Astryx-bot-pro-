// inviteTrackerService.js — caches guild invites, detects which invite a new
// member used, updates persistent invite counts, and announces joins in the
// configured tracker channel.

import { PermissionFlagsBits } from 'discord.js';
import { logger } from '../utils/logger.js';
import { createEmbed } from '../utils/embeds.js';
import { getGuildConfig } from './config/guildConfig.js';
import {
    recordInviteUse,
    getInviterTotalUses,
    getGuildInviteLeaderboard,
} from '../utils/database.js';

// guildId -> Map<inviteCode, { uses, inviterId }>
const inviteCache = new Map();
// guildId -> vanity invite use count (or null if no vanity url / no access)
const vanityCache = new Map();

function snapshotInvites(invites) {
    const snapshot = new Map();
    for (const invite of invites.values()) {
        snapshot.set(invite.code, {
            uses: invite.uses ?? 0,
            inviterId: invite.inviter?.id ?? null,
        });
    }
    return snapshot;
}

/**
 * Fetch and cache all current invites (and vanity URL uses, if available)
 * for a guild. Safe to call repeatedly (ready, guildCreate, inviteCreate/Delete).
 */
export async function cacheGuildInvites(guild) {
    try {
        const me = guild.members.me;
        if (!me?.permissions?.has(PermissionFlagsBits.ManageGuild)) {
            // Without Manage Server we can't read invite uses at all.
            inviteCache.set(guild.id, new Map());
            return;
        }

        const invites = await guild.invites.fetch();
        inviteCache.set(guild.id, snapshotInvites(invites));

        if (guild.features?.includes('VANITY_URL')) {
            try {
                const vanity = await guild.fetchVanityData();
                vanityCache.set(guild.id, vanity?.uses ?? 0);
            } catch (err) {
                vanityCache.set(guild.id, null);
            }
        } else {
            vanityCache.set(guild.id, null);
        }
    } catch (error) {
        logger.warn(`Failed to cache invites for guild ${guild.id}: ${error.message}`);
        inviteCache.set(guild.id, inviteCache.get(guild.id) || new Map());
    }
}

function findChangedInvite(guildId, freshInvites) {
    const previous = inviteCache.get(guildId) || new Map();

    for (const invite of freshInvites.values()) {
        const before = previous.get(invite.code);
        const beforeUses = before?.uses ?? 0;
        const afterUses = invite.uses ?? 0;

        if (afterUses > beforeUses) {
            return { code: invite.code, inviterId: invite.inviter?.id ?? null, uses: afterUses };
        }
    }

    // Invite existed before but is now gone — likely a single-use invite that
    // was just consumed and auto-deleted by Discord.
    for (const [code, data] of previous.entries()) {
        if (!freshInvites.has(code)) {
            return { code, inviterId: data.inviterId, uses: (data.uses ?? 0) + 1 };
        }
    }

    return null;
}

/**
 * Diff the guild's invites against the cache to find which invite a newly
 * joined member used, record the use, and return everything needed to
 * announce the join. Returns null on failure/no permission.
 */
export async function resolveInviteForNewMember(member) {
    const { guild } = member;

    try {
        const me = guild.members.me;
        if (!me?.permissions?.has(PermissionFlagsBits.ManageGuild)) {
            return { via: 'unknown', reason: 'missing_permission' };
        }

        const freshInvites = await guild.invites.fetch();
        const changed = findChangedInvite(guild.id, freshInvites);

        // Always refresh the cache to the latest state.
        inviteCache.set(guild.id, snapshotInvites(freshInvites));

        if (changed) {
            const row = await recordInviteUse({
                guildId: guild.id,
                inviteCode: changed.code,
                inviterId: changed.inviterId,
                uses: 1,
            });

            const totalInvites = changed.inviterId
                ? (row ? Number(row.uses) : await getInviterTotalUses(guild.id, changed.inviterId))
                : null;

            return {
                via: 'invite',
                code: changed.code,
                inviterId: changed.inviterId,
                totalInvites: changed.inviterId ? await getInviterTotalUses(guild.id, changed.inviterId) : null,
            };
        }

        // Check vanity URL usage.
        if (guild.features?.includes('VANITY_URL')) {
            try {
                const vanity = await guild.fetchVanityData();
                const prevUses = vanityCache.get(guild.id) ?? vanity.uses ?? 0;
                vanityCache.set(guild.id, vanity.uses ?? 0);

                if ((vanity.uses ?? 0) > prevUses) {
                    return { via: 'vanity', code: vanity.code };
                }
            } catch (err) {
                // no access / no vanity — ignore
            }
        }

        return { via: 'unknown' };
    } catch (error) {
        logger.warn(`Failed to resolve invite for new member ${member.id} in ${guild.id}: ${error.message}`);
        return { via: 'unknown', reason: 'error' };
    }
}

function buildJoinEmbed(member, resolution) {
    const { user } = member;

    if (resolution.via === 'invite' && resolution.inviterId) {
        return createEmbed({
            title: '📥 New Invite Join',
            color: 'success',
            description: `${user} joined using <@${resolution.inviterId}>'s invite.`,
            fields: [
                { name: 'Invite Code', value: `\`${resolution.code}\``, inline: true },
                { name: 'Inviter Total Invites', value: `${resolution.totalInvites ?? '?'}`, inline: true },
            ],
            thumbnail: user.displayAvatarURL(),
            timestamp: true,
        });
    }

    if (resolution.via === 'invite' && !resolution.inviterId) {
        return createEmbed({
            title: '📥 New Invite Join',
            color: 'primary',
            description: `${user} joined using invite \`${resolution.code}\` (inviter unknown — likely created by an app/integration).`,
            thumbnail: user.displayAvatarURL(),
            timestamp: true,
        });
    }

    if (resolution.via === 'vanity') {
        return createEmbed({
            title: '📥 New Invite Join',
            color: 'primary',
            description: `${user} joined using the server's **vanity invite**.`,
            thumbnail: user.displayAvatarURL(),
            timestamp: true,
        });
    }

    return createEmbed({
        title: '📥 New Member',
        color: 'primary',
        description: `${user} joined, but I couldn't determine which invite was used (may be Discovery, a widget, or a deleted invite).`,
        thumbnail: user.displayAvatarURL(),
        timestamp: true,
    });
}

/**
 * Full pipeline: resolve which invite was used and, if the invite tracker is
 * enabled with a channel configured, post an announcement there.
 */
export async function trackMemberJoin(member) {
    if (member.user.bot) {
        return;
    }

    const resolution = await resolveInviteForNewMember(member);

    try {
        const config = await getGuildConfig(member.client, member.guild.id);
        const trackerChannelId = config?.inviteTracking?.channelId;

        if (!config?.inviteTracking?.enabled || !trackerChannelId) {
            return;
        }

        const channel = member.guild.channels.cache.get(trackerChannelId);
        const me = member.guild.members.me;
        const permissions = channel?.isTextBased?.() && me ? channel.permissionsFor(me) : null;

        if (!permissions?.has([PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.EmbedLinks])) {
            return;
        }

        await channel.send({ embeds: [buildJoinEmbed(member, resolution)] });
    } catch (error) {
        logger.error(`Error announcing invite tracker join for ${member.id} in ${member.guild.id}:`, error);
    }
}

export async function getInviteLeaderboard(guildId, limit = 10) {
    return getGuildInviteLeaderboard(guildId, limit);
}

export async function getInviterCount(guildId, inviterId) {
    return getInviterTotalUses(guildId, inviterId);
}

export function clearGuildInviteCache(guildId) {
    inviteCache.delete(guildId);
    vanityCache.delete(guildId);
}
