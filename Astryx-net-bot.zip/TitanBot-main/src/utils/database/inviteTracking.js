// inviteTracking.js — thin facade over pgDb for the invite tracker feature.

import { pgDb } from '../postgresDatabase.js';

export async function recordInviteUse({ guildId, inviteCode, inviterId, uses = 1, data = {} }) {
    return pgDb.upsertInviteUse({ guildId, inviteCode, inviterId, uses, data });
}

export async function getInviteTrackingRow(guildId, inviteCode) {
    return pgDb.getInviteTrackingRow(guildId, inviteCode);
}

export async function getGuildInviteTracking(guildId) {
    return pgDb.getGuildInviteTracking(guildId);
}

export async function getInviterTotalUses(guildId, inviterId) {
    return pgDb.getInviterTotalUses(guildId, inviterId);
}

export async function getGuildInviteLeaderboard(guildId, limit = 10) {
    return pgDb.getGuildInviteLeaderboard(guildId, limit);
}

export async function deleteInviteTrackingCode(guildId, inviteCode) {
    return pgDb.deleteInviteTrackingCode(guildId, inviteCode);
}

export async function deleteGuildInviteTracking(guildId) {
    return pgDb.deleteGuildInviteTracking(guildId);
}
